
/**
 * Write a description of class Bike here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bike extends Vehicle
{
    // instance variables - replace the example below with your own
    private int numMirrors;
    
    public Bike()
    {
        super();
        numMirrors = 0;
    }
    
    public int compareTo(Bike b)
    {
       return this.numMirrors - b.numMirrors;
    }
          
        
}


