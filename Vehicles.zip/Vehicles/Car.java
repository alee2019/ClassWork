
/**
 * Write a description of class Car here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Car extends Vehicle
{
    private int numPassengers;
    
    public Car()
    {
        super();
        numPassengers = 0;
    }
    
    public int compareTo(Car c)
    {
       return this.numPassengers - c.numPassengers;
    }
          
        
}
