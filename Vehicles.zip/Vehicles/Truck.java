
/**
 * Write a description of class Truck here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Truck extends Vehicle
{
    private int numRadios;
    
    public Truck()
    {
        super();
        numRadios = 0;
    }
    
    public int compareTo(Truck t)
    {
       return this.numRadios - t.numRadios;
    }
          
        
}


