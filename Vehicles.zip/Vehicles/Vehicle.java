
/**
 * Abstract class Vehicle - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Vehicle implements Comparable<Vehicle>
{
  //private String name; 
   private int numWheels;
   private int maxSpeed;
   private int mpg;
   
   public Vehicle()
   {
       
       numWheels = 0;
       maxSpeed = 0;
       mpg = 0;
   }
   
   public int compareTo(Vehicle v)
   {
       return this.mpg - v.mpg;
   }
    
   
}
